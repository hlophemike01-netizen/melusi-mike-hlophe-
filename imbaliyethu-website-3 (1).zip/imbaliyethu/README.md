# Imbaliyethu Funeral Services — Website

A premium, single-page static website for Imbaliyethu Funeral Services
("Umthombo Wentuthuzelo" — Dignity in Every Farewell), built with plain
HTML, CSS and JavaScript so it can be deployed instantly with zero build
step.

## What's included

- `index.html` — the full website (hero, assistance bar, about, services,
  funeral policies, repatriation, why choose us, how it works, national
  coverage, family support, request-assistance form, testimonials, FAQ
  accordion, contact section, footer, floating WhatsApp button, sticky
  mobile action bar)
- `assets/logo.jpg` — the official Imbaliyethu logo, used in the nav,
  footer and favicon

All copy uses only the business information supplied (company name, brand
phrase, motto, Johannesburg head office, nationwide coverage, and the two
phone numbers). No prices, addresses, registration numbers, testimonials,
or other unverified details have been invented — those are clearly marked
as placeholders in the source (e.g. testimonials and social links).

## 1. Run it locally

No build tools are required. Either:

- Double-click `index.html` to open it in a browser, or
- Serve it locally for a closer-to-production preview:
  ```bash
  npx serve .
  # or
  python3 -m http.server 8080
  ```
  then visit `http://localhost:8080`.

## 2. Deploy to Netlify

**Drag-and-drop (fastest):**
1. Go to https://app.netlify.com/drop
2. Drag the whole `imbaliyethu` folder (containing `index.html` and
   `assets/`) into the browser window.
3. Netlify gives you a live URL immediately.

**Git-based deploy:**
1. Push this folder to a GitHub/GitLab repo.
2. In Netlify: **Add new site → Import an existing project**.
3. Build command: leave blank. Publish directory: `.` (repo root).

## 3. Deploy to Vercel

1. Push this folder to a GitHub/GitLab repo.
2. In Vercel: **Add New → Project → Import** the repo.
3. Framework preset: **Other**. Build command: none. Output directory: `.`
4. Deploy — Vercel serves `index.html` as-is.

## 4. Connect a custom domain

Both Netlify and Vercel: open the deployed site's **Domain settings**,
add your domain (e.g. `imbaliyethu.co.za`), and update your domain
registrar's DNS records as instructed on-screen (usually a CNAME or A
record). SSL certificates are issued automatically by both platforms.

## 5. Environment variables

This site has no backend and currently needs none. If you later connect
the "Request Assistance" form to an email service (see below), any API
keys for that service should be added as environment variables in your
Netlify/Vercel dashboard — never hard-coded into `index.html`.

## 6. Connecting the "Request Assistance" form

The form on the page is fully built (validation, layout, success message)
but does **not** currently send data anywhere — it only shows a
confirmation message client-side. To make it functional, pick one:

- **Netlify Forms** (easiest on Netlify): add `netlify` and `name="assist"`
  attributes to the `<form>` tag, redeploy, and Netlify will collect
  submissions automatically — no JS changes required.
- **Formspree**: create a form at formspree.io, then change the `fetch`/
  submit logic in the `<script>` block at the bottom of `index.html` to
  POST to your Formspree endpoint.
- **Custom API**: point the same submit handler at your own backend
  endpoint (e.g. an email-sending serverless function).

## 7. Updating the website later

- **Text**: all copy lives directly in `index.html` — search for the
  section heading (e.g. `id="policies"`) and edit the surrounding text.
- **Logo**: replace `assets/logo.jpg` with an updated file of the same
  name, or update the `src` paths if you rename it.
- **Colours**: all brand colours are defined once at the top of the
  `<style>` block under `:root` (`--black`, `--gold`, `--ivory`, etc.) —
  change them there to restyle the whole site.
- **FAQ items**: edit the `faqs` array near the bottom of the `<script>`
  block.

## Notes on information used

Per the brief, the following are intentionally **not** included because
they were not supplied: street address, email address, registration
number, policy pricing, years of experience, real testimonials, and
social media links. These appear as clearly marked placeholders
(e.g. `[CLIENT TESTIMONIAL TO BE ADDED]`, social icons linking to `#`)
so they can be filled in once available.
